#!/bin/bash

echo " Chatur: aadarniye mere pyare mitro"

echo " rancho: ratta marega to eaise hi hoga "

echo " Chatur: thuchuk chuckuk"

echo " raju: itna hi hai to ek folder bana ke dikha "

mkdir -p Rancho

echo " Rancho: ye le bana diya "

echo " farhan: Virus ne bejjati kr di bol diya farhan nitrate"

echo "abba nahi manenge" > farhan_nitrate.txt


