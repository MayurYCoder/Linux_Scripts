#!/bin/bash

<<info This is explanation of functions
loops: anything that you want to repeat again and again and again till a certain conditions 
for loops conditions
1..10

start point =1
end point = 10
increment +
info

for (( num=1 ; num<=10 ; num++))
do 
	echo "$num"
	echo "hellow"
done

